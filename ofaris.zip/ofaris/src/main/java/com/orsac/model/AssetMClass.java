package com.orsac.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "asset_mt_class")
public class AssetMClass {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name="name_e",nullable = false, unique = true)
    private String nameE;

    @Column(name="name_o")
    private String nameO;

    @Column(name="int_created_by")
    private Integer createdBy;

    @Column(name="int_updated_by")
    private Integer updatedBy;

    private Boolean isActive=true;
}

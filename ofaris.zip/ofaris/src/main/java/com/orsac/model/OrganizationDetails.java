package com.orsac.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="mt_organization_details")
public class OrganizationDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name="org_name")
    private String name;
    @Column(name="org_type")
    private int orgType;
    @Column(name="org_contactno")
    private long contactNo;
    @Column(name="org_contact_person")
    private String contactPerson;
    @Column(name="contact_person_no")
    private long contactPersonNo;
    @Column(name="designation")
    private String designation;
    @Column(name="int_created_by")
    private int createdBy;
    @Column(name="int_updated_by")
    private int updatedBy;
    @Column(name="is_active")
    private boolean isActive;

}

package com.orsac.model;

import com.orsac.dto.Gender;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "m_user_master")
public class UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "int_user_id")
    private int userId;

    @Column(name = "vch_firstname")
    private String firstName;

    @Column(name = "vch_midllename")
    private String middleName;

    @Column(name = "vch_lastname")
    private String lastName;

    @Column(name = "vch_designation")
    private String designation;

    @NotBlank
    @Column(name = "vch_username",unique = true,nullable = false)
    private String userName;

    @Column(name = "vch_password")
    @NotNull
    private String password;

    @Column(name = "int_gender")
    private Gender gender;

    @Column(name = "int_mobile")
    @NotNull
    private long mobile;

    @Column(name = "vch_email")
    private String email;

    @Column(name = "int_role_type")
    private int roleType;

    @Column(name = "int_created_by")
    private int createdBy;

    @Column(name = "int_updated_by")
    private int updatedBy;

    @Column(name = "is_active")
    private boolean isActive=true;

}

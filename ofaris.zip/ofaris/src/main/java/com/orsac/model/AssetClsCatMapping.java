package com.orsac.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "asset_cls_cat_mapping")
public class AssetClsCatMapping {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name="class_id")
    private int classId;

    @Column(name="category_id")
    private int categoryId;

    @Column(name = "is_active")
    private boolean isActive=true;

    @Column(name = "int_created_by")
    private int createdBy;

    @Column(name = "int_updated_by")
    private int updatedBy;
}

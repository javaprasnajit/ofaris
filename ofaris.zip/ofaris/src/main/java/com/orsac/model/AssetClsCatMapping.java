package com.orsac.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "asset_cls_cat_mapping")

@SecondaryTables({
        @SecondaryTable(name = "asset_mt_class", pkJoinColumns = {
                @PrimaryKeyJoinColumn(name = "id", referencedColumnName = "`class_id`")}),
        @SecondaryTable(name = "asset_mt_category", pkJoinColumns = {
                @PrimaryKeyJoinColumn(name = "id", referencedColumnName = "`category_id`")})
})
public class AssetClsCatMapping {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    //private int class_id;
    //private int category_id;

    @Column(name = "is_active")
    private boolean isActive;
    @Column(name = "int_created_by")
    private int createdBy;
    @Column(name = "int_updated_by")
    private int updatedBy;
}

package com.orsac.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "asset_mt_category")
public class AssetMCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name="name_e")
    private String nameE;

    @Column(name = "measuring_unit_1")
    private String measuringUnit1;

    @Column(name = "measuring_unit_2")
    private String measuringUnit2;

    @Column(name = "measuring_unit_3")
    private String measuringUnit3;

    @Column(name = "measuring_unit_4")
    private String measuringUnit4;

    @Column(name = "is_active")
    private Boolean isActive = true;

    @Column(name = "int_created_by")
    private int createdBy;

    @Column(name = "int_updated_by")
    private int updatedBy;

    @Column(name = "asset_area_type")
    private String assetAreaType;


}

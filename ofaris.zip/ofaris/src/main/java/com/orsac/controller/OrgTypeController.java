package com.orsac.controller;

import com.orsac.model.OrgType;
import com.orsac.serviceImpl.OrgTypeServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

@RestController
public class OrgTypeController {

    @Autowired
    private OrgTypeServiceImpl OrgTypeServiceImpl;


    @PostMapping("/saveOrgType")
    public ResponseEntity<String> saveOrgType(@RequestBody OrgType orgType) {
        OrgTypeServiceImpl.saveOrgType(orgType);
        return new ResponseEntity<>("successfully saved", HttpStatus.CREATED);
    }

    @GetMapping("/getAllOrgType")
    public List<OrgType> getAllOrgType() {
        return OrgTypeServiceImpl.getAllOrgType();
    }

    @GetMapping("/findOrgTypeById/{id}")
    public ResponseEntity<OrgType>findOrgTypeById(@PathVariable("id") int id) {
        try {
            OrgType orgType = OrgTypeServiceImpl.getOrgTypeById(id);
            return new ResponseEntity<>(orgType, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/updateOrgTypeById/{id}")
    public ResponseEntity<String> updateOrgTypeById(@RequestBody OrgType orgType, @PathVariable("id") int id) {
        try {
            OrgType type = OrgTypeServiceImpl.getOrgTypeById(id);
            orgType.setId(type.getId());
            OrgTypeServiceImpl.updateOrgType(orgType);
            return new ResponseEntity<>("Updated has been successfully", HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>("User Not found", HttpStatus.NOT_FOUND);
        }
    }

}

package com.orsac.controller;

import com.orsac.model.UserDetails;
import com.orsac.service.UserDetailsService;
import com.orsac.util.PasswordUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.NoSuchElementException;
@RestController
public class UserDetailsController {

    @Autowired
    private UserDetailsService userDetailsService;

    @PostMapping("/saveUserDetails")
    public ResponseEntity<String> saveUserDetails(@Valid @RequestBody UserDetails userDetails) {
        userDetails.setPassword(PasswordUtils.generateSecurePassword(userDetails.getPassword()));
        userDetailsService.saveUserDetails(userDetails);
        return new ResponseEntity<>("User added successfully", HttpStatus.CREATED);
    }

    @GetMapping("/getAllUserDetails")
    public List<UserDetails> getAllUserDetails() {
        return userDetailsService.getAllUser();
    }

    @GetMapping("/getUserById/{id}")
    public ResponseEntity<UserDetails> getUserById(@PathVariable("id") int id) {
        try {
            UserDetails userDetails = userDetailsService.getById(id);
            return new ResponseEntity<>(userDetails, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/updateUserById/{id}")
    public ResponseEntity<String> updateUserById(@RequestBody UserDetails userDetails, @PathVariable("id") int userId) {
        try {
            UserDetails user = userDetailsService.getById(userId);
            userDetails.setUserId(user.getUserId());
            userDetailsService.updateUser(userDetails);
            return new ResponseEntity<>("Updated has been successfully",HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>("User Not found",HttpStatus.NOT_FOUND);
        }
    }
}

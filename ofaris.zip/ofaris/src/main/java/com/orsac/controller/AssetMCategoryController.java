package com.orsac.controller;
import com.orsac.model.AssetMCategory;
import com.orsac.service.AssetMCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

@RestController
public class AssetMCategoryController {

    @Autowired
    private AssetMCategoryService assetMCategoryServices;

    @PostMapping("/saveAssetMCategory")
    public ResponseEntity<String> saveAssetMCategory(@RequestBody AssetMCategory assetMCategory) {
        assetMCategoryServices.saveAssetMCategory(assetMCategory);
        return new ResponseEntity<>("category save successfully",HttpStatus.CREATED);
    }

    @GetMapping("/getAllAssetMCategory")
    public List<AssetMCategory> getAllAsset() {
        return assetMCategoryServices.getAssetMCategory();
    }


    @GetMapping("/getAssetMClassCategoryById/{id}")
    public ResponseEntity<AssetMCategory> getAssetMClassCategoryById(@PathVariable("id") int id) {
        try {
            AssetMCategory assetMCategory = assetMCategoryServices.assetMClassCategoryGetById(id);
            return new ResponseEntity<>(assetMCategory, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/updateAssetMClassCategoryById/{id}")
    public ResponseEntity<AssetMCategory> updateAssetMClassCategoryById(@RequestBody AssetMCategory assetMCategory, @PathVariable("id") int id) {
        try {
            AssetMCategory asset = assetMCategoryServices.assetMClassCategoryGetById(id);
            assetMCategory.setId(asset.getId());
            assetMCategoryServices.UpdateAssetCategory(assetMCategory);
            return new ResponseEntity<>(HttpStatus.OK);
         }  catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}

package com.orsac.controller;

import com.orsac.dto.OFARISResponse;
import com.orsac.model.AssetMCategory;
import com.orsac.serviceImpl.AssetMCategoryServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
public class AssetMCategoryController {

    @Autowired
    private AssetMCategoryServiceImpl AssetMCategoryServiceImpl;


    @PostMapping("/saveAssetMCategory")
    public OFARISResponse saveAssetMCategory(@RequestBody AssetMCategory assetMCategory) {
        return AssetMCategoryServiceImpl.saveAssetMCategory(assetMCategory);

    }

    @GetMapping("/getAllAssetMCategory")
    public OFARISResponse getAllAsset() {
        return AssetMCategoryServiceImpl.getAllAssetMCategory();
    }


    @GetMapping("/getAssetMClassCategoryById/{id}")
    public OFARISResponse getAssetMClassCategoryById(@PathVariable("id") int id) {
        return AssetMCategoryServiceImpl.assetMClassCategoryGetById(id);
    }

    @PutMapping("/updateAssetMClassCategoryById/{id}")
    public OFARISResponse updateAssetMClassCategoryById(@RequestBody AssetMCategory assetMCategory, @PathVariable("id") int id) {
        return AssetMCategoryServiceImpl.UpdateAssetCategory(id, assetMCategory);
    }
}

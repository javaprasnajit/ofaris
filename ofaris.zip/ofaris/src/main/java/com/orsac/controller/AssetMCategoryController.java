package com.orsac.controller;

import com.orsac.dto.OFARISResponse;
import com.orsac.model.AssetMCategory;
import com.orsac.service.AssetMCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class AssetMCategoryController {

    @Autowired
    private AssetMCategoryService assetMCategoryServices;


    @PostMapping("/saveAssetMCategory")
    public ResponseEntity<String> saveAssetMCategory(@RequestBody AssetMCategory assetMCategory) {
        assetMCategoryServices.saveAssetMCategory(assetMCategory);
        return new ResponseEntity<>("category save successfully", HttpStatus.CREATED);
    }

    @GetMapping("/getAllAssetMCategory")
    public OFARISResponse getAllAsset() {
        return assetMCategoryServices.getAllAssetMCategory();
    }

    @GetMapping("/getAssetMClassCategoryById/{id}")
    public OFARISResponse getAssetMClassCategoryById(@PathVariable("id") int id) {
        return assetMCategoryServices.assetMClassCategoryGetById(id);
    }

    @PutMapping("/updateAssetMClassCategoryById/{id}")
    public OFARISResponse updateAssetMClassCategoryById(@RequestBody AssetMCategory assetMCategory, @PathVariable("id") int id) {
        return assetMCategoryServices.UpdateAssetCategory(id,assetMCategory);
    }
}

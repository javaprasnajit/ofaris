package com.orsac.controller;

import com.orsac.dto.OFARISResponse;
import com.orsac.model.AssetMClass;
import com.orsac.model.OrganizationDetails;
import com.orsac.serviceImpl.OrganizationDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class OrganizationDetailsController {

    @Autowired
    private OrganizationDetailsServiceImpl organizationDetailsServiceImpl;

    @PostMapping("/saveOrganizationDetails")
    public OFARISResponse saveOrganizationDetails(@RequestBody OrganizationDetails organizationDetails) {
        return organizationDetailsServiceImpl.saveOrganizationDetails(organizationDetails);
    }

    @GetMapping("/getAllOrganizationDetails")
    public OFARISResponse getAllOrganizationDetails(){
        return organizationDetailsServiceImpl.getAllOrganizationDetails();

    }

    @GetMapping("/getOrganizationDetailsById/{id}")
    public OFARISResponse getOrganizationDetailsById(@PathVariable("id") int id) {
        return organizationDetailsServiceImpl.OrganizationDetailsGetById(id);

    }

    @PutMapping("/updateOrganizationDetailsById/{id}")
    public OFARISResponse updateOrganizationDetailsById(@RequestBody OrganizationDetails organizationDetails, @PathVariable("id") int id) {
        return organizationDetailsServiceImpl.updateOrganizationDetails(id,organizationDetails);
    }


}

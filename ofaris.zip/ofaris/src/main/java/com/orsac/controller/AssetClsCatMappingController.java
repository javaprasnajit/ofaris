package com.orsac.controller;

import com.orsac.dto.OFARISResponse;
import com.orsac.model.AssetClsCatMapping;
import com.orsac.serviceImpl.AssetClsCatMappingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class AssetClsCatMappingController {
    @Autowired
    private AssetClsCatMappingService AssetClsCatMappingService;

    @PostMapping("/saveAssetClsCatMapping")
    public OFARISResponse saveAssetClsCatMapping(@RequestBody AssetClsCatMapping assetClsCatMapping){
       return  AssetClsCatMappingService.saveClassCatMapping(assetClsCatMapping);
    }

    public List<AssetClsCatMapping> getAssetClsCatMapping(){
        return AssetClsCatMappingService.getAllAssetMClassCat();
    }


}

package com.orsac.controller;

import com.orsac.model.AssetClsCatMapping;
import com.orsac.service.AssetClsCatMappingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AssetClsCatMappingController {
    @Autowired
    private AssetClsCatMappingService AssetClsCatMappingService;

    @PostMapping("/saveAssetClsCatMapping")
    public ResponseEntity<String> saveAssetClsCatMapping(@RequestBody AssetClsCatMapping assetClsCatMapping){
        AssetClsCatMappingService.saveClassCatMapping(assetClsCatMapping);
        return new ResponseEntity<>("Added successfully", HttpStatus.CREATED);

    }
}

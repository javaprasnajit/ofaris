package com.orsac.controller;

import com.orsac.dto.OFARISResponse;
import com.orsac.model.AssetMClass;
import com.orsac.serviceImpl.AssetMClassServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
public class AssetMClassController {

    @Autowired
    private AssetMClassServiceImpl assetMClassServiceImpl;

    @PostMapping("/saveAssetMClass")
    public OFARISResponse saveAssetMClass(@RequestBody AssetMClass assetMClass) {
        return assetMClassServiceImpl.saveAssetMClass(assetMClass);
    }

    @GetMapping("/getAllAssetMClass")
    public OFARISResponse getAllAssetMClass(){
        return assetMClassServiceImpl.getAllAssetMClass();
    }

    @GetMapping("/getAssetMClassById/{id}")
    public OFARISResponse getAssetMClassById(@PathVariable("id") int id) {
        return assetMClassServiceImpl.assetMClassGetById(id);

    }

    @PutMapping("/updateAssetMClassById/{id}")
    public OFARISResponse updateAssetMClassById(@RequestBody AssetMClass assetMClass, @PathVariable("id") int id) {
        return assetMClassServiceImpl.updateAssetMClass(id, assetMClass);
    }
}


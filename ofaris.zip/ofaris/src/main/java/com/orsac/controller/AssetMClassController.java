package com.orsac.controller;

import com.orsac.model.AssetMClass;
import com.orsac.service.AssetMClassService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

@RestController
public class AssetMClassController {

    @Autowired
    private AssetMClassService assetMClassServices;

    @PostMapping("/saveAssetMClass")
    public ResponseEntity<String> saveAssetMClass(@RequestBody AssetMClass assetMClass) {
        assetMClassServices.saveAssetMClass(assetMClass);
        return new ResponseEntity<>("save successfully",HttpStatus.CREATED);
    }

    @GetMapping("/getAllAssetMClass")
    public List<AssetMClass> getAllAssetMClass() {
        return assetMClassServices.getAllAssetMClass();
    }

    @GetMapping("/getAssetMClassById/{id}")
    public ResponseEntity<AssetMClass> getAssetMClassById(@PathVariable("id") int id) {
        try {
            AssetMClass assetMClass = assetMClassServices.assetMClassGetById(id);
            return new ResponseEntity<>(assetMClass, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/updateAssetMClassById/{id}")
    public ResponseEntity<AssetMClass> updateAssetMClassById(@RequestBody AssetMClass assetMClass, @PathVariable("id") int id) {
        try {
            AssetMClass asset = assetMClassServices.assetMClassGetById(id);
            assetMClass.setId(asset.getId());
            assetMClassServices.updateAssetMClass(assetMClass);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}


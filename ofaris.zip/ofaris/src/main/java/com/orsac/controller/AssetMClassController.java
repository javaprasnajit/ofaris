package com.orsac.controller;

import com.orsac.dto.OFARISResponse;
import com.orsac.model.AssetMClass;
import com.orsac.service.AssetMClassService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class AssetMClassController {

    @Autowired
    private AssetMClassService assetMClassServices;

    @PostMapping("/saveAssetMClass")
    public OFARISResponse saveAssetMClass(@RequestBody AssetMClass assetMClass) {
        return assetMClassServices.saveAssetMClass(assetMClass);
    }

    @GetMapping("/getAllAssetMClass")
    public List<AssetMClass> getAllAssetMClass() {
        return assetMClassServices.getAllAssetMClass();
    }


    @GetMapping("/getAssetMClassById/{id}")
    public OFARISResponse getAssetMClassById(@PathVariable("id") int id) {
        return assetMClassServices.assetMClassGetById(id);

    }

    @PutMapping("/updateAssetMClassById/{id}")
    public OFARISResponse updateAssetMClassById(@RequestBody AssetMClass assetMClass, @PathVariable("id") int id) {
        return assetMClassServices.updateAssetMClass(id, assetMClass);
    }
}


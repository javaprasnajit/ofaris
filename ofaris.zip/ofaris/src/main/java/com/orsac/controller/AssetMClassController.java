package com.orsac.controller;

import com.orsac.Exception.ExceptionResponse;
import com.orsac.model.AssetMClass;
import com.orsac.service.AssetMClassService;
import javassist.tools.rmi.ObjectNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

@RestController
public class AssetMClassController {

    @Autowired
    private AssetMClassService assetMClassServices;

    @PostMapping("/saveAssetMClass")
    public ResponseEntity<ExceptionResponse> saveAssetMClass(@RequestBody AssetMClass assetMClass) {
        if (assetMClass != null) {
            assetMClassServices.saveAssetMClass(assetMClass);
            return new ResponseEntity<>(HttpStatus.CREATED);
        } else {
            ExceptionResponse er = new ExceptionResponse();
            er.setError("not found");
            er.setMessage("user not added");
            er.setStatus("0");
        }
        return new ResponseEntity<ExceptionResponse>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/getAllAssetMClass")
    public List<AssetMClass> getAllAssetMClass() {
        return assetMClassServices.getAllAssetMClass();
    }

    @GetMapping("/getAssetMClassById/{id}")
    public ResponseEntity<AssetMClass> getAssetMClassById(@PathVariable("id") int id) {
        try {
            AssetMClass assetMClass = assetMClassServices.assetMClassGetById(id);
            return new ResponseEntity<>( assetMClass,HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/updateAssetMClassById/{id}")
    public ResponseEntity<AssetMClass> updateAssetMClassById(@RequestBody AssetMClass assetMClass, @PathVariable("id") int id) {
        try {
            AssetMClass asset = assetMClassServices.assetMClassGetById(id);
            assetMClass.setId(asset.getId());
            assetMClassServices.updateAssetMClass(assetMClass);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}


package com.orsac.controller;

import com.orsac.Exception.ContentNotSupportedException;
import com.orsac.Exception.ForbiddenException;
import com.orsac.dto.OFARISResponse;
import com.orsac.model.AssetMClass;
import com.orsac.service.AssetMClassService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class AssetMClassController {

    @Autowired
    private AssetMClassService assetMClassServices;

    @PostMapping("/saveAssetMClass")
    public OFARISResponse saveAssetMClass(@RequestBody AssetMClass assetMClass) {
        return assetMClassServices.saveAssetMClass(assetMClass);
    }

   /* @GetMapping("/getAllAssetMClass")
    public List<AssetMClass> getAllAssetMClass() {
        return assetMClassServices.getAllAssetMClass();
    }*/

    @GetMapping("/getAllAssetMClass")
    public OFARISResponse getAllAssetMClass() throws ContentNotSupportedException {
        return assetMClassServices.getAllAssetMClass();
    }

    @GetMapping("/getAssetMClassById/{id}")
    public OFARISResponse getAssetMClassById(@PathVariable("id") int id) {
        return assetMClassServices.assetMClassGetById(id);

    }
/*

    @GetMapping("/getAssetMClassById/{id}")
    public Object getAssetMClassById(@PathVariable("id") int id) {
        return assetMClassServices.getAssetMClassById(id);
    }
*/

    @PutMapping("/updateAssetMClassById/{id}")
    public OFARISResponse updateAssetMClassById(@RequestBody AssetMClass assetMClass, @PathVariable("id") int id) {
        return assetMClassServices.updateAssetMClass(id, assetMClass);
    }
}


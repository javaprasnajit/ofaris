package com.orsac.dto;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Data
public class AssetMCategoryDto {

    private Integer id;

    private String name_e;

    private String measuring_unit_1;

    private String measuring_unit_2;

    private String measuring_unit_3;

    private String measuring_unit_4;

    private Boolean IS_active;

    private Integer int_created_by;

    private Integer int_updated_by;

    private String asset_area_type;

}

package com.orsac.dto;

import lombok.Data;

@Data
public class AssetMClassDto {
    private Integer id;

    private String name_e;

    private String name_o;

    private Integer int_created_by;

    private Integer int_updated_by;

    private boolean IS_active ;
}


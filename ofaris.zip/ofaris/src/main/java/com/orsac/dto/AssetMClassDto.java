package com.orsac.dto;

public class AssetMClassDto {
    private int id;

    private String nameE;

    private String nameO;

    private Integer createdBy;

    private Integer updatedBy;

    private Boolean isActive ;
}


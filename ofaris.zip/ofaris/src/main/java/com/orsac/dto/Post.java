package com.orsac.dto;

public class Post {

    private int id;

    private String nameE;

    private String nameO;

    private Integer createdBy;

    private Integer updatedBy;

    private Boolean isActive ;
}


package com.orsac.dto;

public enum Gender {
    MALE, FEMALE
}

package com.orsac.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.orsac.model.AssetMCategory;
import com.orsac.model.AssetMClass;
import lombok.Data;
import org.springframework.context.annotation.Configuration;

@Data
public class OFARISResponse {

    private int status;
    private String message;

    private AssetMClass assetMClass;
    @JsonIgnore
    private AssetMCategory assetMCategory;
}

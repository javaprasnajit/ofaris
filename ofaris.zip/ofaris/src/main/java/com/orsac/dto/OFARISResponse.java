package com.orsac.dto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OFARISResponse {

    private int status;
    private String errorMessage;
    public List<AssetMClassDto> post;
    public List<AssetMCategoryDto> post1;

}

package com.orsac.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.orsac.model.AssetMCategory;
import com.orsac.model.AssetMClass;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OFARISResponse {

    private int status;
    private String errorMessage;
    public List<Post> post=new ArrayList<>();

}

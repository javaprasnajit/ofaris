package com.orsac.repository;

import com.orsac.model.AssetMCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface AssetMCategoryRepository extends JpaRepository<AssetMCategory, Integer> {

    AssetMCategory findById(int id);

}

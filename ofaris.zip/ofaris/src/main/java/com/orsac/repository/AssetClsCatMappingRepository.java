package com.orsac.repository;

import com.orsac.model.AssetClsCatMapping;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AssetClsCatMappingRepository extends JpaRepository<AssetClsCatMapping,Integer> {
}

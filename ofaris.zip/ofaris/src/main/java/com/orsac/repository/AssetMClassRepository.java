package com.orsac.repository;

import com.orsac.model.AssetMClass;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AssetMClassRepository extends JpaRepository<AssetMClass, Integer> {

 AssetMClass findById(int id);

}

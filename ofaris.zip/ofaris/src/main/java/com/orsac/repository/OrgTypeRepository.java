package com.orsac.repository;
import com.orsac.model.OrgType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgTypeRepository extends JpaRepository<OrgType,Integer> {

}

package com.orsac.Exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
public class ContentNotSupportedException extends RuntimeException {

    public ContentNotSupportedException(String message, Throwable cause) {
        super(message, cause);
    }

    public ContentNotSupportedException(String message) {
        super(message);
    }

}

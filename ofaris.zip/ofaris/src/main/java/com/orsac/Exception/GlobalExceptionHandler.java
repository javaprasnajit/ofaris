package com.orsac.Exception;

import javassist.tools.rmi.ObjectNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageConversionException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ResponseStatus(HttpStatus.UNSUPPORTED_MEDIA_TYPE) // 415
    @ExceptionHandler(ContentNotSupportedException.class)
    @ResponseBody
    public ExceptionResponse handleNotSupported(ContentNotSupportedException e) {
        return new ExceptionResponse("Content is not supported",e);
    }

    @ResponseStatus(HttpStatus.CONFLICT) // 409
    @ExceptionHandler(ConflictException.class)
    @ResponseBody
    public ExceptionResponse handleConflict(ConflictException e) {
        return new ExceptionResponse("Conflict", e);
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)  // 404
    @ExceptionHandler(ObjectNotFoundException.class)
    @ResponseBody
    public ExceptionResponse handleNotFound(ObjectNotFoundException e) {
        return new ExceptionResponse("Not found", e);
    }

    @ResponseStatus(HttpStatus.FORBIDDEN)  // 403
    @ExceptionHandler(ForbiddenException.class)
    @ResponseBody
    public ExceptionResponse handleForbidden(ForbiddenException e) {
        return new ExceptionResponse("Forbidden", e);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST) // 400
    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseBody
    public ExceptionResponse handleIllegal(IllegalArgumentException e) {
        return new ExceptionResponse("Bad request", e);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST) // 400
    @ExceptionHandler(HttpMessageConversionException.class)
    @ResponseBody
    public ExceptionResponse handleBadMessageConversion(HttpMessageConversionException e) {
        return new ExceptionResponse("Bad request", e);
    }

    // Fall back
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)  // 500
    @ExceptionHandler(Exception.class)
    @ResponseBody
    public ExceptionResponse handleOtherException(Exception e) {
        return new ExceptionResponse("Internal server error", (ConflictException) e);
    }

}

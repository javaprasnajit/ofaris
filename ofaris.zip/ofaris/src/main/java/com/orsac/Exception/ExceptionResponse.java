package com.orsac.Exception;

import com.fasterxml.jackson.annotation.JsonFormat;
import javassist.tools.rmi.ObjectNotFoundException;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.http.converter.HttpMessageConversionException;

import java.time.LocalDateTime;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ExceptionResponse extends Throwable {

    private String error;
    private String status;
    private String message;

    public ExceptionResponse(String content_is_not_supported, ContentNotSupportedException e) {
    }

    public ExceptionResponse(String conflict, ConflictException e) {
    }

    public ExceptionResponse(String not_found, ObjectNotFoundException e) {
    }

    public ExceptionResponse(String forbidden, ForbiddenException e) {
    }

    public ExceptionResponse(String bad_request, IllegalArgumentException e) {
    }

    public ExceptionResponse(String bad_request, HttpMessageConversionException e) {
    }
}

package com.orsac.serviceImpl;

import com.orsac.model.UserDetails;
import com.orsac.repository.UserDetailsRepository;
import com.orsac.service.UserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UserDetailsRepository userDetailsRepository;

    @Override
    public void saveUserDetails(UserDetails userDetails) {
        userDetailsRepository.save(userDetails);
    }

    @Override
    public List<UserDetails> getAllUser() {
        return userDetailsRepository.findAll();
    }

    @Override
    public UserDetails getById(int id) {
        return userDetailsRepository.findById(id).get();
    }

    @Override
    public void updateUser(UserDetails userDetails) {
        userDetailsRepository.save(userDetails);
    }


}

package com.orsac.serviceImpl;

import com.orsac.dto.OFARISResponse;
import com.orsac.model.AssetClsCatMapping;
import com.orsac.model.AssetMClass;
import com.orsac.repository.AssetClsCatMappingRepository;
import com.orsac.util.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AssetClsCatMappingService {
    @Autowired
     AssetClsCatMappingRepository AssetClsCatMappingRepository;


    @Value("${invalid.input}")
    private String invalidInput;


    @Value("${exception.in.server}")
    private String exceptionInServer;

    @Autowired
    private ConfigurableEnvironment env;

    public OFARISResponse saveClassCatMapping(AssetClsCatMapping assetClsCatMapping) {

        OFARISResponse response = new OFARISResponse();
        try {
            if (assetClsCatMapping != null) {
                AssetClsCatMappingRepository.save(assetClsCatMapping);
                response.setStatus(1);
                response.setErrorMessage(env.getProperty(Constant.SUCCESSFULLY_ADDED));
            } else {
                response.setStatus(0);
                response.setErrorMessage(invalidInput);
            }

            return response;
        } catch (Exception e) {
            response.setStatus(0);
            response.setErrorMessage(exceptionInServer);
            return response;
        }
    }

    public List<AssetClsCatMapping> getAllAssetMClassCat() {
        return AssetClsCatMappingRepository.findAll();
    }

    public AssetClsCatMapping assetMClassCatGetById(int id) {
        return AssetClsCatMappingRepository.findById(id).get();
    }

    public AssetClsCatMapping updateMClassCategory(AssetClsCatMapping assetClsCatMapping){
        return AssetClsCatMappingRepository.save(assetClsCatMapping);
    }
}

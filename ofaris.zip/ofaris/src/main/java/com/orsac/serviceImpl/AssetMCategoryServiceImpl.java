package com.orsac.serviceImpl;

import com.orsac.dto.AssetMCategoryDto;
import com.orsac.dto.OFARISResponse;
import com.orsac.model.AssetMCategory;
import com.orsac.repository.AssetMCategoryRepository;
import com.orsac.service.AssetMCategoryService;
import com.orsac.util.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class AssetMCategoryServiceImpl implements AssetMCategoryService {

    @Autowired
    private AssetMCategoryRepository assetMCategoryRepository;

    @Autowired
    private ConfigurableEnvironment env;

    @Override
    public OFARISResponse saveAssetMCategory(AssetMCategory assetMCategory) {
        OFARISResponse response = new OFARISResponse();
        try {
            if (assetMCategory != null) {
                assetMCategoryRepository.save(assetMCategory);
                response.setStatus(1);
                response.setErrorMessage("");
            } else {
                response.setStatus(0);
                response.setErrorMessage(env.getProperty(Constant.INVALID_INPUT));
            }

            return response;
        } catch (Exception e) {
            response.setStatus(0);
            response.setErrorMessage(env.getProperty(Constant.EXCEPTION_IN_SERVER));
            return response;
        }
    }

    @Override
    public OFARISResponse getAllAssetMCategory() {
        OFARISResponse response = new OFARISResponse();
        try {
            List<AssetMCategory> assetMClassCategoryList = assetMCategoryRepository.findAll();
            if (assetMClassCategoryList != null && !assetMClassCategoryList.isEmpty()) {
                List<AssetMCategoryDto> assetMClassCatDtoList = new ArrayList<>();

                assetMClassCategoryList.stream().forEach(assetMCategory -> {

                    AssetMCategoryDto assetMClassCatDto = new AssetMCategoryDto();
                    assetMClassCatDto.setId(assetMCategory.getId());
                    assetMClassCatDto.setName_e(assetMCategory.getNameE());
                    assetMClassCatDto.setMeasuring_unit_1(assetMCategory.getMeasuringUnit1());
                    assetMClassCatDto.setMeasuring_unit_2(assetMCategory.getMeasuringUnit2());
                    assetMClassCatDto.setMeasuring_unit_3(assetMCategory.getMeasuringUnit3());
                    assetMClassCatDto.setInt_created_by(assetMCategory.getCreatedBy());
                    assetMClassCatDto.setInt_updated_by(assetMCategory.getUpdatedBy());
                    assetMClassCatDto.setIS_active(assetMCategory.getIsActive());
                    assetMClassCatDto.setAsset_area_type(assetMCategory.getAssetAreaType());

                    assetMClassCatDtoList.add(assetMClassCatDto);

                });
                response.setStatus(1);
                response.setErrorMessage("");
                response.setPost1(assetMClassCatDtoList);

            } else {
                response.setStatus(0);
                response.setErrorMessage(env.getProperty(Constant.RECORD_NOT_FOUND));
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(0);
            response.setErrorMessage(env.getProperty(Constant.EXCEPTION_IN_SERVER));
        }
        return response;
    }

    @Override
    public OFARISResponse assetMClassCategoryGetById(int id) {
        OFARISResponse response = new OFARISResponse();
        try {
           AssetMCategory assetMCategory = assetMCategoryRepository.findById(id);

            if (assetMCategory != null) {
                List<AssetMCategoryDto> assetMCategoryDtoList = new ArrayList<>();

                AssetMCategoryDto assetMCategoryDto = new AssetMCategoryDto();
                assetMCategoryDto.setId(assetMCategory.getId());
                assetMCategoryDto.setName_e(assetMCategory.getNameE());
                assetMCategoryDto.setMeasuring_unit_1(assetMCategory.getMeasuringUnit1());
                assetMCategoryDto.setMeasuring_unit_2(assetMCategory.getMeasuringUnit2());
                assetMCategoryDto.setMeasuring_unit_3(assetMCategory.getMeasuringUnit3());
                assetMCategoryDto.setMeasuring_unit_4(assetMCategory.getMeasuringUnit4());
                assetMCategoryDto.setAsset_area_type(assetMCategory.getAssetAreaType());
                assetMCategoryDto.setInt_created_by(assetMCategory.getCreatedBy());
                assetMCategoryDto.setInt_updated_by(assetMCategory.getUpdatedBy());
                assetMCategoryDto.setIS_active(assetMCategory.getIsActive());

                assetMCategoryDtoList.add(assetMCategoryDto);

                response.setStatus(1);
                response.setPost1(assetMCategoryDtoList);

            } else {
                response.setStatus(0);
                response.setErrorMessage(env.getProperty(Constant.INVALID_INPUT));
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(0);
            response.setErrorMessage(env.getProperty((Constant.EXCEPTION_IN_SERVER)));
        }
        return response;
    }

    @Override
    public OFARISResponse UpdateAssetCategory(int id, AssetMCategory assetMCategory) {
        OFARISResponse response = new OFARISResponse();
        try {
            AssetMCategory assetMCategoryFromDB = assetMCategoryRepository.findById(id);

            if (assetMCategoryFromDB != null) {

                assetMCategoryFromDB.setNameE(assetMCategory.getNameE());
                assetMCategoryFromDB.setMeasuringUnit1(assetMCategory.getMeasuringUnit1());
                assetMCategoryFromDB.setMeasuringUnit2(assetMCategory.getMeasuringUnit2());
                assetMCategoryFromDB.setMeasuringUnit3(assetMCategory.getMeasuringUnit3());
                assetMCategoryFromDB.setMeasuringUnit4(assetMCategory.getMeasuringUnit4());
                assetMCategoryFromDB.setCreatedBy(assetMCategory.getCreatedBy());
                assetMCategoryFromDB.setUpdatedBy(assetMCategory.getUpdatedBy());
                assetMCategoryFromDB.setIsActive(assetMCategory.getIsActive());
                assetMCategoryFromDB.setAssetAreaType(assetMCategory.getAssetAreaType());
                assetMCategoryRepository.save(assetMCategoryFromDB);
                response.setStatus(1);
                response.setErrorMessage("");
            } else {
                response.setStatus(0);
                response.setErrorMessage(env.getProperty(Constant.INVALID_INPUT));
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(0);
            response.setErrorMessage(env.getProperty(Constant.EXCEPTION_IN_SERVER));
            return response;
        }
        return response;

    }

}

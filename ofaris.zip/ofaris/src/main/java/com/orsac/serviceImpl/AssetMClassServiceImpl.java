package com.orsac.serviceImpl;

import com.orsac.dto.AssetMClassDto;
import com.orsac.dto.OFARISResponse;
import com.orsac.model.AssetMClass;
import com.orsac.repository.AssetMClassRepository;
import com.orsac.service.AssetMClassService;
import com.orsac.util.Constant;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AssetMClassServiceImpl implements AssetMClassService {


    @Autowired
    private AssetMClassRepository assetMClassRepository;


    @Autowired
    private ConfigurableEnvironment env;

    @Override
    public OFARISResponse saveAssetMClass(AssetMClass assetMClass) {
        OFARISResponse response = new OFARISResponse();
        try {
            if (assetMClass != null) {
                assetMClassRepository.save(assetMClass);
                response.setStatus(1);
                response.setErrorMessage("");
            } else {
                response.setStatus(0);
                response.setErrorMessage(env.getProperty(Constant.INVALID_INPUT));
            }
            return response;

        } catch (Exception e) {
            response.setStatus(0);
            response.setErrorMessage(env.getProperty(Constant.EXCEPTION_IN_SERVER));
            return response;
        }
    }

    @Override
    public OFARISResponse getAllAssetMClass() {
        OFARISResponse response = new OFARISResponse();
        try {
            List<AssetMClass> assetMClassList = assetMClassRepository.findAll();
            if (assetMClassList != null && !assetMClassList.isEmpty()) {
                List<AssetMClassDto> assetMClassDtoList = new ArrayList<>();
                assetMClassList.stream().forEach(assetMClass -> {

                    AssetMClassDto assetMClassDto = new AssetMClassDto();
                    assetMClassDto.setId(assetMClass.getId());
                    assetMClassDto.setName_e(assetMClass.getNameE());
                    assetMClassDto.setName_o(assetMClass.getNameO());
                    assetMClassDto.setInt_created_by(assetMClass.getCreatedBy());
                    assetMClassDto.setInt_updated_by(assetMClass.getUpdatedBy());
                    assetMClassDto.setIS_active(assetMClass.getIsActive());

                    assetMClassDtoList.add(assetMClassDto);

                });
                response.setStatus(1);
                response.setPost(assetMClassDtoList);

            } else {
                response.setStatus(0);
                response.setErrorMessage(env.getProperty(Constant.RECORD_NOT_FOUND));
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(0);
            response.setErrorMessage(env.getProperty(Constant.EXCEPTION_IN_SERVER));
        }
        return response;
    }

    @Override
    public OFARISResponse assetMClassGetById(int id) {

        OFARISResponse response = new OFARISResponse();
        try {
            AssetMClass assetMClass = assetMClassRepository.findById(id);
            if (assetMClass != null) {
                List<AssetMClassDto> assetMClassDtoList = new ArrayList<>();

                AssetMClassDto assetMClassDto = new AssetMClassDto();
                assetMClassDto.setId(assetMClass.getId());
                assetMClassDto.setName_e(assetMClass.getNameE());
                assetMClassDto.setName_o(assetMClass.getNameO());
                assetMClassDto.setInt_created_by(assetMClass.getCreatedBy());
                assetMClassDto.setInt_updated_by(assetMClass.getUpdatedBy());
                assetMClassDto.setIS_active(assetMClass.getIsActive());

                assetMClassDtoList.add(assetMClassDto);

                response.setStatus(1);
                response.setPost(assetMClassDtoList);

            } else {
                response.setStatus(0);
                response.setErrorMessage(env.getProperty(Constant.INVALID_INPUT));
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(0);
            response.setErrorMessage(env.getProperty((Constant.EXCEPTION_IN_SERVER)));
        }
        return response;
    }

    @Override
    public OFARISResponse updateAssetMClass(int id, AssetMClass assetMClass) {
        OFARISResponse response = new OFARISResponse();

        try {
            AssetMClass assetMClassFromDB = assetMClassRepository.findById(id);

            if (assetMClassFromDB != null) {

                assetMClassFromDB.setNameE(assetMClass.getNameE());
                assetMClassFromDB.setNameO(assetMClass.getNameO());
                assetMClassFromDB.setCreatedBy(assetMClass.getCreatedBy());
                assetMClassFromDB.setUpdatedBy(assetMClass.getUpdatedBy());
                assetMClassFromDB.setIsActive(assetMClass.getIsActive());
                assetMClassRepository.save(assetMClassFromDB);

                response.setStatus(1);
            } else {
                response.setStatus(0);
                response.setErrorMessage(env.getProperty(Constant.INVALID_INPUT));
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(0);
            response.setErrorMessage(env.getProperty(Constant.EXCEPTION_IN_SERVER));
            return response;
        }
        return response;

    }

}

package com.orsac.serviceImpl;

import com.orsac.dto.OFARISResponse;
import com.orsac.model.OrganizationDetails;
import com.orsac.repository.OrganizationDetailsRepository;
import com.orsac.service.OrganizationDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrganizationDetailsServiceImpl implements OrganizationDetailsService {
    @Autowired
    private OrganizationDetailsRepository organizationDetailsRepository;

    @Override
    public OFARISResponse saveOrganizationDetails(OrganizationDetails organizationDetails) {
        return null;
    }

    @Override
    public OFARISResponse getAllOrganizationDetails() {
        return null;
    }

    @Override
    public OFARISResponse OrganizationDetailsGetById(int id) {
        return null;
    }

    @Override
    public OFARISResponse updateOrganizationDetails(int id, OrganizationDetails organizationDetails) {
        return null;
    }
}

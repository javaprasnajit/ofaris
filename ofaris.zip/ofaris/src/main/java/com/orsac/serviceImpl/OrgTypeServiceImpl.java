package com.orsac.serviceImpl;

import com.orsac.model.OrgType;
import com.orsac.repository.OrgTypeRepository;
import com.orsac.service.OrgTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrgTypeServiceImpl implements OrgTypeService {

    @Autowired
    private OrgTypeRepository orgTypeRepository;

    @Override
    public void saveOrgType(OrgType type) {
        orgTypeRepository.save(type);
    }

    @Override
    public List<OrgType> getAllOrgType() {
        return orgTypeRepository.findAll();
    }

    @Override
    public OrgType getOrgTypeById(int id) {
        return orgTypeRepository.findById(id);
    }

    @Override
    public void updateOrgType(OrgType orgType) {
        orgTypeRepository.save(orgType);
    }
}

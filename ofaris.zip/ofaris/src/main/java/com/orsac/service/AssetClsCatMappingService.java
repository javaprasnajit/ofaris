package com.orsac.service;

import com.orsac.model.AssetClsCatMapping;
import com.orsac.repository.AssetClsCatMappingRepository;
import com.orsac.repository.AssetMClassRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AssetClsCatMappingService {
    @Autowired
     AssetClsCatMappingRepository AssetClsCatMappingRepository;

    public void saveClassCatMapping(AssetClsCatMapping assetClsCatMapping){
        AssetClsCatMappingRepository.save(assetClsCatMapping);
    }

}

package com.orsac.service;
import com.orsac.model.UserDetails;
import com.orsac.repository.UserDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserDetailsService {

    @Autowired
    private UserDetailsRepository userDetailsRepository;

    public void saveUserDetails(UserDetails userDetails) {
        userDetailsRepository.save(userDetails);
    }

    public List<UserDetails> getAllUser() {
        return userDetailsRepository.findAll();
    }

    public UserDetails getById(int id) {
        return userDetailsRepository.findById(id).get();
    }

    public void updateUser(UserDetails userDetails) {
        userDetailsRepository.save(userDetails);
    }

}

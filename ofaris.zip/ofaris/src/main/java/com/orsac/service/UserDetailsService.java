package com.orsac.service;

import com.orsac.model.UserDetails;

import java.util.List;


public interface UserDetailsService {

    public void saveUserDetails(UserDetails userDetails);

    public List<UserDetails> getAllUser();

    public UserDetails getById(int id);

    public void updateUser(UserDetails userDetails);

}

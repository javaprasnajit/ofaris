package com.orsac.service;

import com.orsac.dto.OFARISResponse;
import com.orsac.model.OrganizationDetails;

public interface OrganizationDetailsService {

    public OFARISResponse saveOrganizationDetails(OrganizationDetails organizationDetails);

    public OFARISResponse getAllOrganizationDetails();

    public OFARISResponse OrganizationDetailsGetById(int id);

    public OFARISResponse updateOrganizationDetails(int id, OrganizationDetails organizationDetails);

}

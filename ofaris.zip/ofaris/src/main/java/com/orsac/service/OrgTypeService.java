package com.orsac.service;

import com.orsac.model.OrgType;
import com.orsac.repository.OrgTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrgTypeService {

    @Autowired
    private OrgTypeRepository orgTypeRepository;

    public void saveOrgType(OrgType type) {
        orgTypeRepository.save(type);
    }

    public List<OrgType> getAllOrgType() {
        return orgTypeRepository.findAll();
    }

    public OrgType getOrgTypeById(int id) {
        return orgTypeRepository.findById(id).get();
    }

    public void updateOrgType(OrgType orgType) {
        orgTypeRepository.save(orgType);
    }

}

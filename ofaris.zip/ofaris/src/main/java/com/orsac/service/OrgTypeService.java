package com.orsac.service;

import com.orsac.model.OrgType;

import java.util.List;

public interface OrgTypeService {

    public void saveOrgType(OrgType type);
    public List<OrgType> getAllOrgType();
    public OrgType getOrgTypeById(int id);
    public void updateOrgType(OrgType orgType);
}

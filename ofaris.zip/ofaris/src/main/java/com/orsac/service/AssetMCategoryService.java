package com.orsac.service;

import com.orsac.model.AssetMCategory;
import com.orsac.repository.AssetMCategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AssetMCategoryService {

    @Autowired
    private AssetMCategoryRepository assetMCategoryRepository;


    public void saveAssetMCategory(AssetMCategory assetMCategory) {
        assetMCategoryRepository.save(assetMCategory);
    }

    public List<AssetMCategory> getAssetMCategory() {
        return assetMCategoryRepository.findAll();
    }
    public AssetMCategory assetMClassCategoryGetById(int id) {
        return assetMCategoryRepository.findById(id).get();
    }

    public void UpdateAssetCategory(AssetMCategory assetMCategory) {
        assetMCategoryRepository.save(assetMCategory);

    }
}

package com.orsac.service;

import com.orsac.dto.OFARISResponse;
import com.orsac.model.AssetMCategory;
import com.orsac.model.AssetMClass;
import com.orsac.repository.AssetMCategoryRepository;
import com.orsac.util.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AssetMCategoryService {

    @Autowired
    private AssetMCategoryRepository assetMCategoryRepository;

    @Value("${invalid.input}")
    private String invalidInput;


    @Value("${exception.in.server}")
    private String exceptionInServer;

    @Autowired
    private ConfigurableEnvironment env;


    public OFARISResponse saveAssetMCategory(AssetMCategory assetMCategory) {
        OFARISResponse response = new OFARISResponse();
        try {
            if (assetMCategory != null) {
                assetMCategoryRepository.save(assetMCategory);
                response.setStatus(1);
                response.setErrorMessage(env.getProperty(Constant.SUCCESSFULLY_ADDED));
            } else {
                response.setStatus(0);
                response.setErrorMessage(invalidInput);
            }

            return response;
        } catch (Exception e) {
            response.setStatus(0);
            response.setErrorMessage(exceptionInServer);
            return response;
        }
    }

    public List<AssetMCategory> getAssetMCategory() {
        return assetMCategoryRepository.findAll();
    }

    public OFARISResponse assetMClassCategoryGetById(int id) {
        //return assetMCategoryRepository.findById(id).get();
        OFARISResponse response = new OFARISResponse();
        try {
            Optional<AssetMCategory> assetMCategory = assetMCategoryRepository.findById(id);
            if (assetMCategory.isPresent()) {
                AssetMCategory asset = assetMCategory.get();
                response.setStatus(1);
                response.setErrorMessage("");
            // response.setPost(new ArrayList<>(asset));
            } else {
                response.setStatus(0);
                response.setErrorMessage(invalidInput);
            }
            return response;
        } catch (Exception e) {
            response.setStatus(0);
            response.setErrorMessage(exceptionInServer);
            return response;
        }
    }

    public OFARISResponse UpdateAssetCategory(int id, AssetMCategory assetMCategory) {
        OFARISResponse response = new OFARISResponse();
        try {
            if (assetMCategoryRepository.findById(id).isPresent()) {
                AssetMCategory asset = assetMCategoryRepository.findById(id).get();
                assetMCategoryRepository.save(assetMCategory);
                response.setStatus(1);
                response.setErrorMessage(env.getProperty(Constant.SUCCESSFULLY_UPDATED));
            } else {
                response.setStatus(0);
                response.setErrorMessage(invalidInput);
            }
            return response;
        } catch (Exception e) {
            response.setStatus(0);
            response.setErrorMessage(exceptionInServer);
            return response;
        }

    }
}

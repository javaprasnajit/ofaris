package com.orsac.service;
import com.orsac.dto.OFARISResponse;
import com.orsac.model.AssetMCategory;
import java.util.List;


public interface AssetMCategoryService {

    public OFARISResponse saveAssetMCategory(AssetMCategory assetMCategory);

    public OFARISResponse getAllAssetMCategory();

    public OFARISResponse assetMClassCategoryGetById(int id);

    public OFARISResponse UpdateAssetCategory(int id, AssetMCategory assetMCategory);
}

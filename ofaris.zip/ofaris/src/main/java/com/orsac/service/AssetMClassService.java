package com.orsac.service;

import com.orsac.dto.OFARISResponse;
import com.orsac.model.AssetMCategory;
import com.orsac.model.AssetMClass;
import com.orsac.repository.AssetMClassRepository;
import com.orsac.util.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AssetMClassService {
    @Autowired
    private AssetMClassRepository assetMClassRepository;

    @Value("${invalid.input}")
    private String invalidInput;


    @Value("${exception.in.server}")
    private String exceptionInServer;

    @Autowired
    private ConfigurableEnvironment env;


    public OFARISResponse saveAssetMClass(AssetMClass assetMClass) {
        OFARISResponse response = new OFARISResponse();
        try {
            if (assetMClass != null) {
                assetMClassRepository.save(assetMClass);
                response.setStatus(1);
                response.setMessage(env.getProperty(Constant.SUCCESSFULLY_ADDED));
            } else {
                response.setStatus(0);
                response.setMessage(invalidInput);
            }

            return response;
        } catch (Exception e) {
            response.setStatus(0);
            response.setMessage(exceptionInServer);
            return response;
        }
    }

    public List<AssetMClass> getAllAssetMClass() {
        return assetMClassRepository.findAll();
    }


    public OFARISResponse assetMClassGetById(int id) {

        OFARISResponse response = new OFARISResponse();
        try {
            Optional<AssetMClass> assetMClass = assetMClassRepository.findById(id);

            if (assetMClass.isPresent()) {
                AssetMClass asset = assetMClass.get();
                response.setStatus(1);
                response.setMessage(env.getProperty(Constant.SUCCESSFULLY_GetDetails));
                response.setAssetMClass(asset);
            } else {
                response.setStatus(0);
                response.setMessage(invalidInput);
            }
            return response;
        } catch (Exception e) {
            response.setStatus(0);
            response.setMessage(exceptionInServer);
            return response;
        }

    }

    public OFARISResponse updateAssetMClass(int id, AssetMClass assetMClass) {
        OFARISResponse response = new OFARISResponse();
        try {
            if (assetMClassRepository.findById(id).isPresent()) {
                AssetMClass dbasset = assetMClassRepository.findById(id).get();
                dbasset.setNameE(assetMClass.getNameE());
                dbasset.setNameO(assetMClass.getNameO());
                dbasset.setCreatedBy(assetMClass.getCreatedBy());
                dbasset.setUpdatedBy(assetMClass.getUpdatedBy());
                dbasset.setIsActive(assetMClass.getIsActive());
                assetMClassRepository.save(dbasset);
                response.setStatus(1);
                response.setMessage(env.getProperty(Constant.SUCCESSFULLY_UPDATED));
            } else {
                response.setStatus(0);
                response.setMessage(invalidInput);
            }
            return response;
        } catch (Exception e) {
            response.setStatus(0);
            response.setMessage(exceptionInServer);
            return response;
        }

    }
}

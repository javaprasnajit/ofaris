package com.orsac.service;

import com.orsac.dto.AssetMClassDto;
import com.orsac.dto.OFARISResponse;
import com.orsac.dto.Post;
import com.orsac.model.AssetMClass;
import com.orsac.repository.AssetMClassRepository;
import com.orsac.util.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AssetMClassService {
    @Autowired
    private AssetMClassRepository assetMClassRepository;

    @Value("${invalid.input}")
    private String invalidInput;


    @Value("${exception.in.server}")
    private String exceptionInServer;

    @Autowired
    private ConfigurableEnvironment env;


    public OFARISResponse saveAssetMClass(AssetMClass assetMClass) {
        OFARISResponse response = new OFARISResponse();
        try {
            if (assetMClass != null) {
                assetMClassRepository.save(assetMClass);
                response.setStatus(1);
                response.setErrorMessage("");
                response.setPost(new ArrayList<>());
                // response.setErrorMessage(env.getProperty(Constant.SUCCESSFULLY_ADDED));
            } else {
                response.setStatus(0);
                response.setErrorMessage(invalidInput);
            }
            return response;
        } catch (Exception e) {
            response.setStatus(0);
            response.setErrorMessage(exceptionInServer);
            return response;
        }
    }

  /*  public List<AssetMClass> getAllAssetMClass() {
        return assetMClassRepository.findAll();
    }*/


    public OFARISResponse getAllAssetMClass() {
        OFARISResponse response = new OFARISResponse();
        try {
            assetMClassRepository.findAll();
            response.setStatus(1);
            response.setErrorMessage("");
            return response;
        } catch (Exception e) {
            response.setStatus(0);
            response.setErrorMessage(exceptionInServer);
            return response;
        }
    }
/*
    public Optional<AssetMClass> getAssetMClassById(int id) {
        return assetMClassRepository.findById(id);
    }*/


    public OFARISResponse assetMClassGetById(int id) {

        OFARISResponse response = new OFARISResponse();
        try {
            if (assetMClassRepository.findById(id).isPresent()) {
                Optional<AssetMClass> dbasset = assetMClassRepository.findById(id);
                response.setStatus(1);
                response.setErrorMessage("");
                response.setPost(new ArrayList<Post>());

            } else {
                response.setStatus(0);
                response.setErrorMessage(invalidInput);
            }
            return response;
        } catch (Exception e) {
            response.setStatus(0);
            response.setErrorMessage(exceptionInServer);
            return response;
        }
    }


    public OFARISResponse updateAssetMClass(int id, AssetMClass assetMClass) {
        OFARISResponse response = new OFARISResponse();
        try {
            if (assetMClassRepository.findById(id).isPresent()) {
                AssetMClass dbasset = assetMClassRepository.findById(id).get();
                dbasset.setNameE(assetMClass.getNameE());
                dbasset.setNameO(assetMClass.getNameO());
                dbasset.setCreatedBy(assetMClass.getCreatedBy());
                dbasset.setUpdatedBy(assetMClass.getUpdatedBy());
                dbasset.setIsActive(assetMClass.getIsActive());
                assetMClassRepository.save(dbasset);
                response.setStatus(1);
                response.setErrorMessage("");
                response.setPost(new ArrayList<>());
                // response.setErrorMessage(env.getProperty(Constant.SUCCESSFULLY_UPDATED));
            } else {
                response.setStatus(0);
                response.setErrorMessage(invalidInput);
            }
            return response;
        } catch (Exception e) {
            response.setStatus(0);
            response.setErrorMessage(exceptionInServer);
            return response;
        }

    }
}

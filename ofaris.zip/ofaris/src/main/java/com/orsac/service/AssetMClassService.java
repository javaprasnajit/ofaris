package com.orsac.service;

import com.orsac.model.AssetMClass;
import com.orsac.repository.AssetMClassRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AssetMClassService {
    @Autowired
    private AssetMClassRepository assetMClassRepository;


    public void saveAssetMClass(AssetMClass assetMClass) {
        assetMClassRepository.save(assetMClass);
    }

    public List<AssetMClass> getAllAssetMClass() {
        return assetMClassRepository.findAll();
    }

    public AssetMClass assetMClassGetById(int id) {
        return assetMClassRepository.findById(id).get();
    }

   /* public Contact findById(Long uuid) {
        Contact contact = this.contactRepository.findOne(uuid);
        if(contact == null)
            throw new ObjectNotFoundException("Could not find contact with id '" + uuid + "'");
        return contact;
    }*/


    public void updateAssetMClass(AssetMClass assetMClass) {
        assetMClassRepository.save(assetMClass);
    }
}

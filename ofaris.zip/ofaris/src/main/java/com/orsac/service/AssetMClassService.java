package com.orsac.service;

import com.orsac.dto.OFARISResponse;
import com.orsac.model.AssetMClass;

public interface AssetMClassService {

    public OFARISResponse saveAssetMClass(AssetMClass assetMClass);

    public OFARISResponse getAllAssetMClass();

    public OFARISResponse assetMClassGetById(int id);

    public OFARISResponse updateAssetMClass(int id, AssetMClass assetMClass);


}

package com.orsac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OfarisApplication {

	public static void main(String[] args) {
		SpringApplication.run(OfarisApplication.class, args);
	}

}

package com.orsac.util;

public class Constant {

    public static final String SUCCESSFULLY_ADDED = "successfully.added";
    public static final String SUCCESSFULLY_UPDATED = "successfully.updated";
    public static final String SUCCESSFULLY_GetDetails = "successfully.getDetails";
    public static final String INVALID_INPUT = "invalid.input";
    public static final String RECORD_NOT_FOUND="Record.not.found";
    public static final String EXCEPTION_IN_SERVER="exception.in.server";
}

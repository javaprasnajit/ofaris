package com.orsac.util;

public class Constant {

    public static final String SUCCESSFULLY_ADDED = "successfully.added";
    public static final String SUCCESSFULLY_UPDATED = "successfully.updated";
    public static final String SUCCESSFULLY_GetDetails = "successfully.getDetails";
}

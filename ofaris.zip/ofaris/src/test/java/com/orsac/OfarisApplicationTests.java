package com.orsac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfarisApplicationTests {

	@Test
	void contextLoads() {
	}

}
